
function speakText() {
  const text = document.getElementById("searchInput").value;
  if (!text) return;

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerText = "Thinking...";
  document.getElementById("chatOutput").appendChild(bubble);

  fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer 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"
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: text }]
    })
  })
  .then(res => res.json())
  .then(data => {
    const reply = data.choices?.[0]?.message?.content || "I couldn't respond.";
    bubble.innerText = reply;
    const utterance = new SpeechSynthesisUtterance(reply);
    speechSynthesis.speak(utterance);
  })
  .catch(err => {
    bubble.innerText = "Error getting response";
  });
}

function startListening() {
  const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.start();

  recognition.onresult = function(event) {
    const speechText = event.results[0][0].transcript;
    document.getElementById("searchInput").value = speechText;
    speakText();
  };

  recognition.onerror = function(event) {
    alert("Error occurred in recognition: " + event.error);
  };
}
